﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace YappiesTesting.Migrations.yappiesTesting
{
    public partial class newnewdoodoo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Programs_Parents_Messages_MessageID",
                schema: "YT",
                table: "Programs_Parents");

            migrationBuilder.DropIndex(
                name: "IX_Programs_Parents_MessageID",
                schema: "YT",
                table: "Programs_Parents");

            migrationBuilder.DropColumn(
                name: "MessageID",
                schema: "YT",
                table: "Programs_Parents");

            migrationBuilder.AddColumn<int>(
                name: "From",
                schema: "YT",
                table: "Messages",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "MessagesVM",
                schema: "YT",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Subject = table.Column<string>(nullable: true),
                    Body = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(nullable: false),
                    ParentFullName = table.Column<string>(nullable: true),
                    Supervisor = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MessagesVM", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MessagesVM",
                schema: "YT");

            migrationBuilder.DropColumn(
                name: "From",
                schema: "YT",
                table: "Messages");

            migrationBuilder.AddColumn<int>(
                name: "MessageID",
                schema: "YT",
                table: "Programs_Parents",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Programs_Parents_MessageID",
                schema: "YT",
                table: "Programs_Parents",
                column: "MessageID");

            migrationBuilder.AddForeignKey(
                name: "FK_Programs_Parents_Messages_MessageID",
                schema: "YT",
                table: "Programs_Parents",
                column: "MessageID",
                principalSchema: "YT",
                principalTable: "Messages",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
