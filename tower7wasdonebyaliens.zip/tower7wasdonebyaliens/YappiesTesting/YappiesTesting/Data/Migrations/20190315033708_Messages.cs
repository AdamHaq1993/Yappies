﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace YappiesTesting.Migrations.yappiesTesting
{
    public partial class Messages : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MessageID",
                schema: "YT",
                table: "Programs_Parents",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Messages",
                schema: "YT",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Subject = table.Column<string>(maxLength: 500, nullable: true),
                    Body = table.Column<string>(maxLength: 1000000, nullable: false),
                    Date = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Messages", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MessageParents",
                schema: "YT",
                columns: table => new
                {
                    ParentID = table.Column<int>(nullable: false),
                    MessageID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MessageParents", x => new { x.MessageID, x.ParentID });
                    table.ForeignKey(
                        name: "FK_MessageParents_Messages_MessageID",
                        column: x => x.MessageID,
                        principalSchema: "YT",
                        principalTable: "Messages",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MessageParents_Parents_ParentID",
                        column: x => x.ParentID,
                        principalSchema: "YT",
                        principalTable: "Parents",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MessagePs",
                schema: "YT",
                columns: table => new
                {
                    ProgramSupervisorID = table.Column<int>(nullable: false),
                    MessageID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MessagePs", x => new { x.MessageID, x.ProgramSupervisorID });
                    table.ForeignKey(
                        name: "FK_MessagePs_Messages_MessageID",
                        column: x => x.MessageID,
                        principalSchema: "YT",
                        principalTable: "Messages",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MessagePs_ProgramSupervisors_ProgramSupervisorID",
                        column: x => x.ProgramSupervisorID,
                        principalSchema: "YT",
                        principalTable: "ProgramSupervisors",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Programs_Parents_MessageID",
                schema: "YT",
                table: "Programs_Parents",
                column: "MessageID");

            migrationBuilder.CreateIndex(
                name: "IX_MessageParents_ParentID",
                schema: "YT",
                table: "MessageParents",
                column: "ParentID");

            migrationBuilder.CreateIndex(
                name: "IX_MessagePs_ProgramSupervisorID",
                schema: "YT",
                table: "MessagePs",
                column: "ProgramSupervisorID");

            migrationBuilder.AddForeignKey(
                name: "FK_Programs_Parents_Messages_MessageID",
                schema: "YT",
                table: "Programs_Parents",
                column: "MessageID",
                principalSchema: "YT",
                principalTable: "Messages",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Programs_Parents_Messages_MessageID",
                schema: "YT",
                table: "Programs_Parents");

            migrationBuilder.DropTable(
                name: "MessageParents",
                schema: "YT");

            migrationBuilder.DropTable(
                name: "MessagePs",
                schema: "YT");

            migrationBuilder.DropTable(
                name: "Messages",
                schema: "YT");

            migrationBuilder.DropIndex(
                name: "IX_Programs_Parents_MessageID",
                schema: "YT",
                table: "Programs_Parents");

            migrationBuilder.DropColumn(
                name: "MessageID",
                schema: "YT",
                table: "Programs_Parents");
        }
    }
}
