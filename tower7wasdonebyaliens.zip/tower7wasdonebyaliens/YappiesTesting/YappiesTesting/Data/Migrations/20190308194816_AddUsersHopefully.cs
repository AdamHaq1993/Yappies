﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace YappiesTesting.Migrations.yappiesTesting
{
    public partial class AddUsersHopefully : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
