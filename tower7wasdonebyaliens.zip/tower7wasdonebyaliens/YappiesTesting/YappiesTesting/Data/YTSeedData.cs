﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using YappiesTesting.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YappiesTesting.Data
{
    public static class YTSeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new yappiesTestingContext(
                serviceProvider.GetRequiredService<DbContextOptions<yappiesTestingContext>>()))
            {
                //Program Supervisors
                if (!context.ProgramSupervisors.Any())
                {
                    context.ProgramSupervisors.AddRange(
                    new ProgramSupervisor
                    {
                        FirstName = "Michael",
                        LastName = "Meme",
                        Email = "mememachine@yahoo.com",
                        Phone = 2895039392
                    },

                    new ProgramSupervisor
                    {
                        FirstName = "Rick",
                        LastName = "Ross",
                        Email = "rickyrossy@gmail.com",
                        Phone = 9053849384
                    },

                    new ProgramSupervisor
                    {
                        FirstName = "Stephen",
                        LastName = "Database",
                        Email = "w3schoolsboi@hotmail.com",
                        Phone = 2899119111
                    },

                    new ProgramSupervisor
                    {
                        FirstName = "Eric",
                        LastName = "Ribeye",
                        Email = "demonspeaker22@outlook.com",
                        Phone = 2896669898
                    },

                    new ProgramSupervisor
                    {
                        FirstName = "Felix",
                        LastName = "Medi",
                        Email = "stomacheater@gmail.com",
                        Phone = 2894903929
                    },

                    new ProgramSupervisor
                    {
                        FirstName = "Adam",
                        LastName = "Singer",
                        Email = "pianolover@hotmail.com",
                        Phone = 9059492999
                    },

                    new ProgramSupervisor
                    {
                        FirstName = "Ken",
                        LastName = "Dall",
                        Email = "kdall1@hotmail.com",
                        Phone = 2899054929
                    },

                    new ProgramSupervisor
                    {
                        FirstName = "Stovey",
                        LastName = "Boi",
                        Email = "fordpickupsrule@gmail.com",
                        Phone = 9042942999
                    });
                    context.SaveChanges();
                }
                //Programs
                if (!context.Programs.Any())
                {
                    context.Programs.AddRange(
                    new Models.Program
                    {
                        ProgramName = "Adult Lane Swims",
                        ProgramDescription = "Participants may pay daily or purchase a pass. Enjoy a relaxing swim or work on strokes during this adult only pool time. (1-hour swim)",
                        ProgramJoinCode = "AAAAAAAAAA",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Meme").ID
                    },
                    new Models.Program
                    {
                        ProgramName = "Swimmer 1-6",
                        ProgramDescription = "Our swimmer program makes sure children learn how to swim before they get in too deep. Swimmer progressions accommodate 5-12 years old children and youth including absolute beginners as well as swimmers who want to build on the basics. We stress lots of in-water practice to develop solid swimming strokes and skills. We incorporate Water Smart education at all levels. (45-minute lesson)",
                        ProgramJoinCode = "BBBBBBBBBB",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Ross").ID
                    },
                    new Models.Program
                    {
                        ProgramName = "Ball Hockey",
                        ProgramDescription = "They shoot, they score! What a way to learn Canada's favourite past time. Your child will develop coordination, teamwork and game strategy while making friends and having fun. Skills are enhanced through drills and games.",
                        ProgramJoinCode = "CCCCCCCCCC",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Database").ID
                    },
                    new Models.Program
                    {
                        ProgramName = "Basketball",
                        ProgramDescription = "Come and dribble your cares away with this fun introduction to an exciting sport. Skills of the game are taught and reinforced through drills and practices. Slam dunk!",
                        ProgramJoinCode = "DDDDDDDDDD",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Ribeye").ID
                    },
                    new Models.Program
                    {
                        ProgramName = "Gymnastics 9-12 yrs",
                        ProgramDescription = "The recreational gymnastics classes are designed to teach children the basics of the sport with emphasis on skill building and fun. Certified instructors will be working with the children on coo-ordination, balance and flexibility while keeping safety in mind. children will participate in the following disciplines, floor, low beam, mini trampoline and vault.",
                        ProgramJoinCode = "EEEEEEEEEE",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Medi").ID
                    },
                    new Models.Program
                    {
                        ProgramName = "Fort Erie Teen Zone",
                        ProgramDescription = "The Teen Zone is open for youth ages 13-19 years. Many activities are planned by youth themselves. Youth can access computers and assistance with resume writing or job searching, open gym time, games room, computer labs and out trips. Themed nights like a coffee house, and movie nights are organized throughout the year. Fort Erie Centre - 20 Lewis Street Tuesdays and Thursdays 7:00 PM-9:00 PM",
                        ProgramJoinCode = "FFFFFFFFFF",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Singer").ID
                    },
                    new Models.Program
                    {
                        ProgramName = "JR Dance",
                        ProgramDescription = "This program is an introduction to the world of dance for your child. The children will explore the fundamentals of ballet in a safe and nurturing environment. This program focuses on movement, co-ordination and spatial awareness. The emphasis of the program is on having fun.",
                        ProgramJoinCode = "GGGGGGGGGG",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Dall").ID
                    },
                    new Models.Program
                    {
                        ProgramName = "Bronze Star",
                        ProgramDescription = "Bronze Star is the pre-bronze medallion training standard and excellent preparation for success in Bronze Medallion. Participants develop problem solving and decision making skills as individuals and in partners. Participants will learn CPR and develop Water Smart, confidence and the lifesaving skills needed to be a lifeguard.",
                        ProgramJoinCode = "HHHHHHHHHH",
                        ProgramSupervisorID = context.ProgramSupervisors.FirstOrDefault(p => p.LastName == "Boi").ID
                    });
                    context.SaveChanges();
                }

                //Parent
                if (!context.Parents.Any())
                {
                    context.Parents.AddRange(
                        new Parent
                        {
                            FirstName = "Steve",
                            LastName = "Buscemi",
                            Email = "stevebuscemi@yahoo.com",
                            Phone = 2894923456
                        },

                        new Parent
                        {
                            FirstName = "Kenny",
                            LastName = "Rogers",
                            Email = "kennyrogers@gmail.com",
                            Phone = 9056578976
                        },

                        new Parent
                        {
                            FirstName = "Robert",
                            LastName = "De Niro",
                            Email = "taxidriver@hotmail.com",
                            Phone = 2895849054
                        },

                        new Parent
                        {
                            FirstName = "Alec",
                            LastName = "Baldwin",
                            Email = "alecbalwinny@yahoo.com",
                            Phone = 9056754534
                        },

                        new Parent
                        {
                            FirstName = "Tracy",
                            LastName = "Morgan",
                            Email = "tracymorgan@outlook.com",
                            Phone = 9054788989
                        },

                        new Parent
                        {
                            FirstName = "Michael",
                            LastName = "Scott",
                            Email = "theoffice@outlook.com",
                            Phone = 2893895465
                        },

                        new Parent
                        {
                            FirstName = "Rob",
                            LastName = "Stark",
                            Email = "whyyoustabme@gmail.com",
                            Phone = 2896758789
                        },

                        new Parent
                        {
                            FirstName = "Kevin",
                            LastName = "Hart",
                            Email = "hartK@hotmail.com",
                            Phone = 5048765675
                        });
                    context.SaveChanges();
                }

                //Parent Programs
                if (!context.Programs_Parents.Any())
                {
                    for (int i = 1; i <= 8; i++)
                    {
                        Random random = new Random();
                        int num = random.Next(1, 8);
                        for (int j = 1; j <= num; j++)
                        {
                            context.Add(
                                new Program_Parent
                                {
                                    ProgramID = i,
                                    ParentID = j
                                }
                            );
                        }
                    }
                    context.SaveChanges();
                }

                // Activity
                if (!context.Activities.Any())
                {
                    context.Activities.AddRange(
                        // adult swimming lane
                        new Activity
                        {
                            Title = "Women's Free Swim 1",
                            Description = "Session for the women's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(4),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Women's Free Swim 2",
                            Description = "Session for the women's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(8),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Women's Free Swim 3",
                            Description = "Session for the women's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(12),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Women's Free Swim 4",
                            Description = "Session for the women's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(16),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Women's Free Swim 5",
                            Description = "Session for the women's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(20),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Men's Free Swim 1",
                            Description = "Session for the men's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(2),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Men's Free Swim 2",
                            Description = "Session for the men's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(6),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Men's Free Swim 3",
                            Description = "Session for the men's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(10),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Men's Free Swim 4",
                            Description = "Session for the men's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(14),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Men's Free Swim 5",
                            Description = "Session for the men's divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(18),
                            ProgramID = 1
                        },
                        // swimmer 1-6
                        new Activity
                        {
                            Title = "Junior Division Lesson 1",
                            Description = "Lesson for the junior divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(1),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Junior Division Lesson 2",
                            Description = "Lesson for the junior divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(3),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Junior Division Lesson 3",
                            Description = "Lesson for the junior divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(5),
                            ProgramID = 1
                        },
                        new Activity
                        {
                            Title = "Junior Division Lesson 4",
                            Description = "Lesson for the junior divsion of the program, be sure to come prepared as usual.",
                            Date = DateTime.Now.AddDays(7),
                            ProgramID = 1
                        },
                        // ball hockey
                        new Activity
                        {
                            Title = "Game 1 of Juniors",
                            Description = "Game for the junior ball hockey players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(3),
                            ProgramID = 2
                        },
                        new Activity
                        {
                            Title = "Game 2 of Juniors",
                            Description = "Game for the junior ball hockey players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(6),
                            ProgramID = 2
                        },
                        new Activity
                        {
                            Title = "Game 1 of Seniors",
                            Description = "Game for the senior ball hockey players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(4),
                            ProgramID = 2
                        },
                        new Activity
                        {
                            Title = "Game 2 of Seniors",
                            Description = "Game for the senior ball hockey players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(7),
                            ProgramID = 2
                        },
                        // basketball
                        new Activity
                        {
                            Title = "Game 1 of Juniors",
                            Description = "Game for the junior basketball players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(2),
                            ProgramID = 3
                        },
                        new Activity
                        {
                            Title = "Game 2 of Juniors",
                            Description = "Game for the junior basketball players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(9),
                            ProgramID = 3
                        },
                        new Activity
                        {
                            Title = "Game 3 of Juniors",
                            Description = "Game for the junior basketball players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(16),
                            ProgramID = 3
                        },
                        new Activity
                        {
                            Title = "Game 1 of Seniors",
                            Description = "Game for the senior basketball players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(4),
                            ProgramID = 3
                        },
                        new Activity
                        {
                            Title = "Game 1 of Seniors",
                            Description = "Game for the senior basketball players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(11),
                            ProgramID = 3
                        },
                        new Activity
                        {
                            Title = "Game 1 of Seniors",
                            Description = "Game for the senior basketball players, good luck everyone and be sure to come prepared!",
                            Date = DateTime.Now.AddDays(18),
                            ProgramID = 3
                        },
                        // gymnastics 9-12 yrs
                        new Activity
                        {
                            Title = "Lesson 1 - Basics",
                            Description = "Covering basic beginnings, come with the proper change of clothes to get a bit chalky.",
                            Date = DateTime.Now.AddDays(2),
                            ProgramID = 4
                        },
                        new Activity
                        {
                            Title = "Lesson 2 - The Cartwheel",
                            Description = "Covering how to cartwheel, come with the proper change of clothes to get a bit chalky.",
                            Date = DateTime.Now.AddDays(9),
                            ProgramID = 4
                        },
                        new Activity
                        {
                            Title = "Lesson 1 - Standing Triple Twist Double Backflips",
                            Description = "Covering unrealistic gymnastical abilities for 9-12 year olds to learn, come with the proper change of clothes to get a bit chalky.",
                            Date = DateTime.Now.AddDays(16),
                            ProgramID = 4
                        },
                        // fort erie teen zone
                        new Activity
                        {
                            Title = "Spring Blast!!",
                            Description = "Get ready for an extremely fun night with the teen zone!",
                            Date = DateTime.Now.AddDays(5),
                            ProgramID = 5
                        },
                        // jr dance
                        new Activity
                        {
                            Title = "Modern Dance",
                            Description = "Modern style at a modern pace.",
                            Date = DateTime.Now.AddDays(3),
                            ProgramID = 6
                        },
                        new Activity
                        {
                            Title = "Line-style Dance",
                            Description = "Line dancing, country style.",
                            Date = DateTime.Now.AddDays(10),
                            ProgramID = 6
                        },
                        new Activity
                        {
                            Title = "Dance For Fun",
                            Description = "Let's blow off some steam everyone, had a stressful couple weeks.",
                            Date = DateTime.Now.AddDays(17),
                            ProgramID = 6
                        },
                        // bronze star
                        new Activity
                        {
                            Title = "Bronze Star Level Training 1",
                            Description = "Bronze Star Training",
                            Date = DateTime.Now.AddDays(3),
                            ProgramID = 7
                        });
                    context.SaveChanges();
                }
            }
        }
    }
}
