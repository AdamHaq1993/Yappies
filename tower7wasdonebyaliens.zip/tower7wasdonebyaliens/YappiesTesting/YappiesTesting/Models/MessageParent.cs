﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace YappiesTesting.Models
{
    public class MessageParent
    {
        [Display(Name = "Parent")]
        [Required(ErrorMessage = "Parent is required.")]
        public int ParentID { get; set; }

        [Display(Name = "Message")]
        [Required(ErrorMessage = "Message is required.")]
        public int MessageID { get; set; }

        public virtual Parent Parent { get; set; }
        public virtual Message Messages { get; set; }
    }
}
