﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace YappiesTesting.Models
{
    public class Message
    {
        public int ID { get; set; }

        [StringLength(500)]
        public string Subject { get; set; }

        [Required(ErrorMessage = "Message requires a body")]
        [StringLength(1000000)]
        public string Body { get; set; }

        [DataType(DataType.DateTime)]
        [Required(ErrorMessage = "Messages require a date sent")]
        public DateTime Date { get; set; }

        public string From { get; set; }
        public string To { get; set; }
        public virtual ICollection<MessageParent> Parents { get; set; }
        public virtual ICollection<MessagePS> ProgramSupervisors { get; set; }

    }
}
