﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using YappiesTesting.Data;
using YappiesTesting.Migrations.yappiesTesting;
using YappiesTesting.Models;

namespace YappiesTesting.Controllers
{
    public class MessagesController : Controller
    {
        private readonly yappiesTestingContext _context;

        public MessagesController(yappiesTestingContext context)
        {
            _context = context;
        }

        // GET: Messages
        public async Task<IActionResult> Index()
        {
            return View(await _context.Messages.ToListAsync());
        }

        public async Task<IActionResult> ParentIndex()
        {
             return View(await _context.Messages.ToListAsync());
        }
        public async Task<IActionResult> SupervisorIndex()
        {
            return View(await _context.Messages.ToListAsync());
        }


        public async Task<IActionResult> Conversation(string itemFrom)
        {
            List<Messages> Messagelist = new List<Messages>();                           
           return View(await _context.Messages.ToListAsync());
        }

        // GET: Messages/Details/5
        public async Task<IActionResult> Details(int? id)
        {

            ViewData["ItemTo"] = new SelectList(_context.ProgramSupervisors, "ID", "Supervisor");
            if (id == null)
            {
                return NotFound();
            }

            var message = await _context.Messages
                .FirstOrDefaultAsync(m => m.ID == id);
            if (message == null)
            {
                return NotFound();
            }

            return View(message);
        }

        // GET: Messages/Create
        public IActionResult Create()
        {
            ViewData["To"] = new SelectList(_context.ProgramSupervisors, "Email", "Supervisor");

            return View();
        }
        // GET: Messages/Create
        public IActionResult ParentCreate(string Supervisor)
        {
            ViewData["To"] = Supervisor;
            return View("ParentCreate");
        }

        public IActionResult SupervisorCreate()
        {
            ViewData["To"] = new SelectList(_context.Parents, "Email", "Parent Name");

            return View("SupervisorCreate");
        }


        // POST: Messages/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Subject,Body,Date,From,To,ParentID,MessageID,ProgramSupervisorID")] Message message)
        {
            //Sends Message to A program supervisor selected from a list


            if (User.IsInRole("Parent"))
            {
                if (ModelState.IsValid)
                {
                    var supervisor = _context.ProgramSupervisors.SingleOrDefault(p => p.Email == message.To);
                    message.From = User.Identity.Name;
                    message.Date = DateTime.Now;
                    _context.Add(message);
                    _context.Add(new MessagePS
                    {
                        MessageID = message.ID,
                        ProgramSupervisorID = supervisor.ID
                    });                   
                }
            }
            if (User.IsInRole("Program Supervisor"))
            {
                if (ModelState.IsValid)
                {
                    var parent = _context.Parents.SingleOrDefault(p => p.Email == message.To);
                    message.From = User.Identity.Name;
                    message.Date = DateTime.Now;
                    _context.Add(message);
                    _context.Add(new MessageParent
                    {
                        MessageID = message.ID,
                        ParentID = parent.ID
                    });
                }

            }


            await _context.SaveChangesAsync();




            ////Sends Message to A parent
            //var parent = _context.Parents.SingleOrDefault(p => p.Email == this.User.Identity.Name);
            //if (ModelState.IsValid)
            //{
            //    _context.Add(message);

            //    _context.Add(new MessageParent
            //    {
            //        MessageID = message.ID,
            //        ParentID = parent.ID
            //    });
            //    await _context.SaveChangesAsync();

            //}
            //message.To = parent.Email;
            //message.From = User.Identity.Name;
            // return View(message);
            return RedirectToAction(nameof(Index));

        }



        // GET: Messages/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var message = await _context.Messages.FindAsync(id);
            if (message == null)
            {
                return NotFound();
            }
            return View(message);
        }

        // POST: Messages/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Subject,Body,Date")] Message message)
        {
            if (id != message.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(message);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MessageExists(message.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(message);
        }

        // GET: Messages/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var message = await _context.Messages
                .FirstOrDefaultAsync(m => m.ID == id);
            if (message == null)
            {
                return NotFound();
            }

            return View(message);
        }

        // POST: Messages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var message = await _context.Messages.FindAsync(id);
            _context.Messages.Remove(message);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MessageExists(int id)
        {
            return _context.Messages.Any(e => e.ID == id);
        }
    }
}
