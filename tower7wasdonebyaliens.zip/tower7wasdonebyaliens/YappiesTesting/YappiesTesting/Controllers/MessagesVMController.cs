﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using YappiesTesting.Data;
using YappiesTesting.ViewModels;
using YappiesTesting.Models;
using Microsoft.EntityFrameworkCore;
using YappiesTesting.Migrations.yappiesTesting;

namespace YappiesTesting.Controllers
{
    public class MessagesVMController : Controller
    {
        private readonly yappiesTestingContext _context;

        [HttpPost]
        public IActionResult Index(int? ParentID, int? PsID)
        {
            List<MessagesVM> MessagesVMlist = new List<MessagesVM>();
            //maybe this
            var messageListParent = from m in _context.MessageParents
                             .Include(m => m.ParentID)
                             .Include(m => m.MessageID)
                             .Include(m => m.Messages)
                             .ThenInclude(m => m.Subject)
                             .Include(m => m.Messages)
                             .ThenInclude(m => m.Body)
                             .Include(m => m.Messages)
                             .ThenInclude(m => m.Date)
                             select m;

            var messageListPs = from m in _context.MessagePs
                                .Include(m => m.ProgramSupervisorID)
                                .Include(m => m.MessageID)
                                .Include(m => m.Messages)
                                .ThenInclude(m => m.Subject)
                                .Include(m => m.Messages)
                                .ThenInclude(m => m.Body)
                                .Include(m => m.Messages)
                                .ThenInclude(m => m.Date)
                                select m;

            if (ParentID.HasValue)
            {
                messageListParent = messageListParent.Where(m => m.ParentID == ParentID);
            }
            if (PsID.HasValue)
            {
                messageListPs = messageListPs.Where(m => m.ProgramSupervisorID == PsID);
            }
            //maybe not

            //second attempt, defo delete some of this
            if (User.IsInRole("Parent"))
            {
                //Loop thru and fill list with stuff
                foreach (var msg in messageListParent)
                {
                    MessagesVM objVM = new MessagesVM();
                    objVM.Subject = msg.Messages.Subject;
                    objVM.Body = msg.Messages.Body;
                    objVM.Date = msg.Messages.Date;
                    MessagesVMlist.Add(objVM);
                }
            }
            if (User.IsInRole("Program Supervisor"))
            {
                //Loop thru and fill list with stuff
                foreach (var msg in messageListPs)
                {
                    MessagesVM objVM = new MessagesVM();
                    objVM.Subject = msg.Messages.Subject;
                    objVM.Body = msg.Messages.Body;
                    objVM.Date = msg.Messages.Date;        
                    MessagesVMlist.Add(objVM);
                }
            }
            return View(MessagesVMlist);//returns list of messages
        }

    }
}