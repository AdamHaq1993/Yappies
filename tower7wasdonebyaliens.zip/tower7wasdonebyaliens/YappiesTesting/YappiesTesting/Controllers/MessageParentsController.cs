﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using YappiesTesting.Data;
using YappiesTesting.Models;

namespace YappiesTesting.Controllers
{
    public class MessageParentsController : Controller
    {
        private readonly yappiesTestingContext _context;

        public MessageParentsController(yappiesTestingContext context)
        {
            _context = context;
        }

        // GET: MessageParents
        public async Task<IActionResult> Index()
        {
            var yappiesTestingContext = _context.MessageParents.Include(m => m.Messages).Include(m => m.Parent);
            return View(await yappiesTestingContext.ToListAsync());
        }

        // GET: MessageParents/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var messageParent = await _context.MessageParents
                .Include(m => m.Messages)
                .Include(m => m.Parent)
                .FirstOrDefaultAsync(m => m.MessageID == id);
            if (messageParent == null)
            {
                return NotFound();
            }

            return View(messageParent);
        }

        // GET: MessageParents/Create
        public IActionResult Create()
        {
            ViewData["MessageID"] = new SelectList(_context.Messages, "ID", "Body");
            ViewData["ParentID"] = new SelectList(_context.Parents, "ID", "Email");
            return View();
        }

        // POST: MessageParents/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ParentID,MessageID")] MessageParent messageParent)
        {
            if (ModelState.IsValid)
            {
                _context.Add(messageParent);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MessageID"] = new SelectList(_context.Messages, "ID", "Body", messageParent.MessageID);
            ViewData["ParentID"] = new SelectList(_context.Parents, "ID", "Email", messageParent.ParentID);
            return View(messageParent);
        }

        // GET: MessageParents/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var messageParent = await _context.MessageParents.FindAsync(id);
            if (messageParent == null)
            {
                return NotFound();
            }
            ViewData["MessageID"] = new SelectList(_context.Messages, "ID", "Body", messageParent.MessageID);
            ViewData["ParentID"] = new SelectList(_context.Parents, "ID", "Email", messageParent.ParentID);
            return View(messageParent);
        }

        // POST: MessageParents/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ParentID,MessageID")] MessageParent messageParent)
        {
            if (id != messageParent.MessageID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(messageParent);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MessageParentExists(messageParent.MessageID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MessageID"] = new SelectList(_context.Messages, "ID", "Body", messageParent.MessageID);
            ViewData["ParentID"] = new SelectList(_context.Parents, "ID", "Email", messageParent.ParentID);
            return View(messageParent);
        }

        // GET: MessageParents/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var messageParent = await _context.MessageParents
                .Include(m => m.Messages)
                .Include(m => m.Parent)
                .FirstOrDefaultAsync(m => m.MessageID == id);
            if (messageParent == null)
            {
                return NotFound();
            }

            return View(messageParent);
        }

        // POST: MessageParents/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var messageParent = await _context.MessageParents.FindAsync(id);
            _context.MessageParents.Remove(messageParent);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MessageParentExists(int id)
        {
            return _context.MessageParents.Any(e => e.MessageID == id);
        }
    }
}
